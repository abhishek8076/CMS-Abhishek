export const option = [
  {
    id: 1,
    name: 'Html',
  },
  {
    id: 2,
    name: 'File',
  },
  {
    id: 3,
    name: 'Internal Link',
  },
  {
    id: 4,
    name: 'External Link',
  },
  
];
