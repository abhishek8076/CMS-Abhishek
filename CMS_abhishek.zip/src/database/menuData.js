export const Home1 = [
  { value: 'option1', label: 'Option 1' },
  { value: 'option2', label: 'Option 2' },
  { value: 'option3', label: 'Option 3' },
];



export const AboutUs = {
  option1: [
    { value: 'suboption1', label: 'Suboption 1' },
    { value: 'suboption2', label: 'Suboption 2' },
  ],
  option2: [
    { value: 'suboption3', label: 'Suboption 3' },
    { value: 'suboption4', label: 'Suboption 4' },
  ],
  option3: [
    { value: 'suboption5', label: 'Suboption 5' },
    { value: 'suboption6', label: 'Suboption 6' },
  ],
};